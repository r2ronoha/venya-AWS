# angularjs-timepicker
AngularJS directive of timepicker and datepicker with IOS alarm style. You can fit it in your 
mobile html5 app for ios style animation feel timepicker. It is a base. You can decorate your own
style timepicker by modifying css.

##Guidance:

###Run the demo:
1. Please install a webserver locally. Put the files in web root. 
2. Open index.html by http://127.0.0.1/xxxx  (xxxx is up to your web server port) with chrome
3. config chrome to view page in device mode. (Reason: touch event handler can only be responded in mobile device.)

###How to fit the directive in your code
Please check the demo code. Just simply put the directive in your html desired position:


    <timepicker hour='hour' minute='minute'></timepicker>


note: *two-way data binding $scope.hour and $scope.minute by 'hour' and 'minute' property*

![timepicker demo](http://ww2.sinaimg.cn/thumb150/61dcf372jw1eymf4yhh0jj20hi0g6jsc.jpg)